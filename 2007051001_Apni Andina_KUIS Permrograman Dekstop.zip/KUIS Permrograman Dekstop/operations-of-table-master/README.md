# operation-of-table
This project we show you how to insert &amp; update &amp; delete and save data in Database and load it to TableView using javaFx and MySQL
