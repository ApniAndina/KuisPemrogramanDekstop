
package tableView;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import helpers.DbConnect;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import models.Student;

public class AddStudentController implements Initializable {

    @FXML
    private JFXTextField nameFld;
    @FXML
    private JFXDatePicker tanggalraziaFld;
    @FXML
    private JFXTextField jumlahhpFld;
    @FXML
    private JFXTextField tipehpFld;

    String query = null;
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement preparedStatement;
    Student student = null;
    private boolean update;
    int studentId;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void save(MouseEvent event) {

        connection = DbConnect.getConnect();
        String name = nameFld.getText();
        String tanggal_razia = String.valueOf(tanggalraziaFld.getValue());
        String jumlah_hp = jumlahhpFld.getText();
        String tipe_hp = tipehpFld.getText();

        if (name.isEmpty() || tanggal_razia.isEmpty() || jumlah_hp.isEmpty() || tipe_hp.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please Fill All DATA");
            alert.showAndWait();

        } else {
            getQuery();
            insert();
            clean();

        }

    }

    @FXML
    private void clean() {
        nameFld.setText(null);
        tanggalraziaFld.setValue(null);
        jumlahhpFld.setText(null);
        tipehpFld.setText(null);
        
    }

    private void getQuery() {

        if (update == false) {
            
            query = "INSERT INTO `student`( `name`, `tanggal_razia`, `jumlah_hp`, `tipe_hp`) VALUES (?,?,?,?)";

        }else{
            query = "UPDATE `student` SET "
                    + "`name`=?,"
                    + "`tanggal_razia`=?,"
                    + "`jumlah_hp`=?,"
                    + "`tipe_hp`= ? WHERE id = '"+studentId+"'";
        }

    }

    private void insert() {

        try {

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nameFld.getText());
            preparedStatement.setString(2, String.valueOf(tanggalraziaFld.getValue()));
            preparedStatement.setString(3, jumlahhpFld.getText());
            preparedStatement.setString(4, tipehpFld.getText());
            preparedStatement.execute();

        } catch (SQLException ex) {
            Logger.getLogger(AddStudentController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void setTextField(int id, String name, LocalDate tanggal_razia,String jumlah_hp, String tipe_hp) {

        studentId = id;
        nameFld.setText(name);
        tanggalraziaFld.setValue(tanggal_razia);
        jumlahhpFld.setText(jumlah_hp);
        tipehpFld.setText(tipe_hp);

    }

    void setUpdate(boolean b) {
        this.update = b;

    }

}
