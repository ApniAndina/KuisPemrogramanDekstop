
package models;

import java.sql.Date;


public class Student {
    
    
    int id,jumlah_hp  ;
    String name ;
    Date tanggal_razia ;
    String tipe_hp;

    public Student(int id, String name, Date tanggal_razia, int jumlah_hp, String tipe_hp) {
        this.id = id;
        this.name = name;
        this.tanggal_razia = tanggal_razia;
        this.jumlah_hp = jumlah_hp;
        this.tipe_hp = tipe_hp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getTanggal_razia() {
        return tanggal_razia;
    }

    public void setTanggal_razia(Date tanggal_razia) {
        this.tanggal_razia = tanggal_razia;
    }

    public int getJumlah_hp() {
        return jumlah_hp;
    }

    public void setJumlah_hp(int jumlah_hp) {
        this.jumlah_hp = jumlah_hp;
    }

    public String getTipe_hp() {
        return tipe_hp;
    }

    public void setTipe_hp(String tipe_hp) {
        this.tipe_hp = tipe_hp;
    }

    public Object getTanggalrazia() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
}
